package application.controller;

import java.io.IOException;
import java.util.ArrayList;

import application.model.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class MainController implements EventHandler<ActionEvent> {

	@FXML
	Button button1;
	@FXML
	TextArea txtResult;
	@FXML
	TextField txtInput;
	Fleet Anakin;
	@Override
	
	/**
	*  Method that handles files and by starshipsByName
	*  @param actionEvent
	*/
	public void handle(ActionEvent actionEvent) {
		txtResult.clear();
		ArrayList<Starship> jedi;
		Anakin = new Fleet("United Federation of Planets");
		try {
			Anakin.loadStarShips( "data/fleet.csv" );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Anakin.loadCrewMembers( "data/personnel.csv" );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String input = txtInput.getText();
		jedi = Anakin.getStarshipsByName(input);
		if(jedi.isEmpty()) {
			input = "Starship does not exist";
			txtResult.setText(input);
		} else {
			for(int i = 0; i < jedi.size(); i++ ) {
				txtResult.appendText(jedi.get(i).toString());
			}
		}
		
	}
	
}
